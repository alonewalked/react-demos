export default {
  YELLOW: 'yellow',
  BLUE: 'blue'
};